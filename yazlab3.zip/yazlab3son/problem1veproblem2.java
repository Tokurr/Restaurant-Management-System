package yazlab3son;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;

public class problem1veproblem2 {

	public static void main(String[] args) {
	
		JFrame frame = new JFrame("restoran yonetim sistemi");

        JButton problem1Buton = new JButton("Problem 1");
        JButton problem2Buton = new JButton("Problem 2");
        problem1Buton.setBounds(700,300,150,45);
        problem2Buton.setBounds(700,380,150,45);

        problem1Buton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
        
            try {
                Anagui.main(args);
            } catch (Exception ex) {
                ex.printStackTrace();
            }
            
            
            }
        });



        problem2Buton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
            	
            	
            	   try {
                       Main.main(args);
                   } catch (Exception ex) {
                       ex.printStackTrace();
                   }
                      	
            	
            	
            	
            	
            	
            	
            	
            	
            	
            	
            	
            	
            }
       
        
        
        
        
        
        
        
        
        
        
        
        });




        frame.add(problem1Buton);
        frame.add(problem2Buton);
        frame.setExtendedState(JFrame.MAXIMIZED_BOTH);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLayout(null);
        frame.setVisible(true);
		
		
	
		
		
	}
	
	
	
	
	
	

}

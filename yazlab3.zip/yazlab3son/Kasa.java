package yazlab3son;


public class Kasa {

    public boolean kasaUygunMu = true;
    public Kasa() {
    }
}

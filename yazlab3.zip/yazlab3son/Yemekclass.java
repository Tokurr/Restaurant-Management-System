package yazlab3son;


public class Yemekclass {
	public static int yemeksayisi;
	
	
	
	public static boolean yemekvarmi=true;//yemek bittimi diye bayrak
}

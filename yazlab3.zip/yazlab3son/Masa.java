package yazlab3son;

public class Masa {
	  public  boolean bosMu=true;
	    public Masa() {
	    }
	}
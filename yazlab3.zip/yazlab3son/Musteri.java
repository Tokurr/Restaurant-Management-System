package yazlab3son;


public class Musteri {

    public boolean oncelikliMi = false;
    public int beklemeSuresi = 0;
    public boolean bekliyorMu= true;
    public int masaOturmaSuresi = 0; // gerek var mı
    public int siparisVermeSuresi = 0; // gerek var mı
    public boolean siparisVerdimi = false;
    public boolean siparisSureciBasladiMi = false;
    public boolean yemegiHazirlaniyorMu = false;
    public boolean yemegiHazirMi = false;

    public boolean yemekYendiMi = false;

    public boolean bittiMi = false;
    public int yemekYemeSuresi = 0;


    public int hesapOdemeSuresi = 0;
    int garsonNo = -1;
    public int masaNo = -1;

    public Musteri() {
    }
}
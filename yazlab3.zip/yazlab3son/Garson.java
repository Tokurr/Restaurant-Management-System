package yazlab3son;


public class Garson {

    boolean bosMu = true;
    int siparisAlmaSuresi = 0;
    int musteriNo = -1;
    public Garson() {
    }
}

package yazlab3son;


public class Asci {

    boolean bosMu1 = true;
    int yemekHazirlamaSuresi1 = 0;
    int musteriNo1 = 0;

    boolean bosMu2 = true;
    int yemekHazirlamaSuresi2 = 0;
    int musteriNo2 = 0;

    public Asci() {
    }
}
